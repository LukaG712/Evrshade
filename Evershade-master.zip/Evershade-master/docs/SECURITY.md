﻿# Evershade Security Model

**Version:** 1.3.0
**Last Updated:** 2026-10-24

---

## 1. Security Principles

Evershade's security model is built on five core principles:

1. **Least privilege** – Every service runs with minimal permissions.
2. **Defense in depth** – Multiple layers of protection; no single point of failure.
3. **Network isolation** – Services communicate on an internal network; only the gateway is exposed.
4. **Secrets protection** – Credentials are encrypted at rest and never logged.
5. **Untrusted content** – All external content (web pages, repositories, notes) is treated as untrusted data.

### Security at a Glance

For beginners, here's what this means in practice:

| Concern | How Evershade Protects You |
|---------|---------------------------|
| **Data privacy** | All data stays on your machine. Nothing leaves unless you connect an external LLM. |
| **Secret safety** | API keys are encrypted (AES-256-GCM) when stored. Never logged or exposed. |
| **Network security** | Only port 8080 is exposed. All other services are on an internal network. |
| **Container security** | Services run in hardened containers with dropped privileges and read-only filesystems. |
| **Web security** | CSRF protection, rate limiting, and input validation on all endpoints. |

---

## 2. Authentication

### Service-to-Service

All services authenticate using API keys passed via the `Authorization: Bearer` header. Query parameter authentication (`x_key`, `api-key`) has been **removed** – it is no longer supported. All services use constant-time comparison (`hmac.compare_digest`) to prevent timing attacks.

**Auth header format:**
```
Authorization: Bearer <your-api-key>
```

### User Authentication

Greenie provides browser-based user authentication with:

- **Username/password login** via `POST /api/auth/login`
- **Password hashing** using bcrypt (12 rounds) with SHA-256 salted fallback
- **HMAC-signed session tokens** stored in HTTP-only, SameSite=Lax cookies
- **Session expiration** (default 8 hours, configurable via `SESSION_MAX_AGE`)
- **Session revocation** on logout and password change
- **Role-based access control**: admin, user, viewer roles
- **Default admin user** created on first startup (set `ADMIN_PASSWORD` env var)
- **User management API** for admins: create, update, disable, reset password
- **Secure cookie settings**: httponly, samesite, configurable secure flag
- **Persistence**: Users and sessions stored in SQLite via feature_store
- **Session cleanup**: Expired and revoked sessions are automatically purged

API endpoints:
- `POST /api/auth/login` – Login with username/password
- `POST /api/auth/logout` – Logout and revoke session
- `GET /api/auth/me` – Get current user profile
- `PUT /api/auth/me` – Update profile (display name, email)
- `POST /api/auth/me/password` – Change password
- `GET /api/auth/session` – Check authentication status
- `GET /api/auth/users` – List all users (admin)
- `POST /api/auth/users` – Create user (admin)
- `PUT /api/auth/users/{username}` – Update user (admin)
- `DELETE /api/auth/users/{username}` – Disable user (admin)
- `POST /api/auth/users/{username}/reset-password` – Reset password (admin)

User sessions are separate from service-to-service API key authentication.
API keys authenticate service clients; user sessions authenticate browser users.

### API Tokens

- Scoped tokens (read-only, operator, admin)
- Revocable at any time
- Shown only once at creation
- Stored securely (Windows Credential Manager or permission-protected file)

---

## 3. Network Security

### Default Deployment

- Only Greenie (port 8080) is published to the host
- All other services are on an internal Docker network
- No direct host access to Slinker, Trapper, Gobber, or supporting services

### Server Mode

- Greenie binds to all interfaces (`0.0.0.0`)
- Reverse proxy (Caddy) provides TLS termination
- Trusted proxy headers (`X-Forwarded-For`, `X-Forwarded-Proto`) are validated

### Container Hardening

Every service container applies:
- `cap_drop: ALL` – Drop all Linux capabilities (except Caddy's `NET_BIND_SERVICE`)
- `security_opt: no-new-privileges` – Prevent privilege escalation
- `read_only: true` – Read-only root filesystem (all services except Ollama, which needs writable model storage)
- `tmpfs` mounts for writable directories (`/tmp`, `/app/data`, `/app/logs`)
- Resource limits (CPU, memory, processes)
- Ollama binds to `0.0.0.0` inside the container for internal network access, not `127.0.0.1`

---

## 4. Secrets Management

### Hider Service

- AES-256-GCM authenticated encryption for all secrets at rest
- Encryption key derived from `ENCRYPTION_KEY` environment variable via SHA-256
- SQLite persistence – secrets survive container restarts
- Secrets are never logged or exposed in list API responses (only in GET by key)
- 96-bit random nonce per encryption operation (no nonce reuse)
- **Important:** Set a strong `ENCRYPTION_KEY` in production. Default key will be blocked in server mode.

### API Keys

- Generate unique keys per service: `openssl rand -hex 32`
- Never commit `.env` files to version control
- Server mode refuses to start with default keys
- Key rotation supported without downtime

---

## 5. Agent Execution Security

### Slinker Isolation Levels

| Level | Security Boundary | Use Case |
|-------|-------------------|----------|
| `worktree` | **None** – shares host filesystem | Trusted development only (opt-in) |
| `container` | **Yes** – isolated container | **Default** for untrusted code |
| `workstation` | **Yes** – full VM isolation | Maximum isolation |

### Command Execution

- Per-task workspaces with explicit repository boundaries
- Execution time and resource limits
- Cancellation and cleanup on failure
- Concurrent job isolation

---

## 6. Prompt Injection Defense

All content from external sources is treated as **data, not instructions**:

- Web pages scraped by Trapper
- Repository files accessed by Slinker
- Obsidian notes indexed by Gobber
- Retrieved memory entries
- External tool output

**Rules:**
1. Untrusted content cannot trigger tool calls
2. Untrusted content cannot grant or bypass approvals
3. Untrusted content cannot change permissions or request secrets
4. Approval prompts show the concrete action, not model-written justification
5. Planning (reading untrusted content) is separated from execution (side effects)

---

## 7. Browser Security (Trapper)

- URL allowlisting and private IP blocking
- Cloud metadata endpoint blocking
- Redirect abuse prevention
- Resource exhaustion protection
- Browser isolation from host network

---

## 8. Emergency Stop

The emergency stop (`evershade panic`) provides a global kill switch:

1. Pauses all workflow execution and triggers
2. Cancels running Slinker jobs and cleans up sandboxes
3. Optionally revokes active sessions and tokens
4. Records an audit event
5. Sends notification via Poltergeist (if available)
6. Can be reversed deliberately

---

## 8. CSRF Protection

Greenie implements CSRF protection for cookie-authenticated browser sessions:

- CSRF tokens are required for state-changing requests (POST, PUT, DELETE)
- Bearer-authenticated API clients are exempt (not vulnerable to CSRF)
- Origin/Referer header validation for cross-origin requests
- Configurable excluded paths (health checks, metrics, etc.)

## 9. Rate Limiting

Greenie applies rate limiting to prevent abuse:

- **Authentication failures**: 10 failures per 60 seconds per IP address
- **Expensive operations**: Stricter limits for LLM requests (20/min), code execution (5/min), workflow creation (10/min), web crawling (10/min)
- **Default limit**: 60 requests per minute for other endpoints
- Sliding window algorithm with per-IP and per-API-key tracking
- Configurable via `RATE_LIMIT_ENABLED` and `RATE_LIMIT_DEFAULT_REQUESTS` environment variables

## 10. Idempotency

Retryable operations support idempotency keys via the `X-Idempotency-Key` header:

- Safe retries for workflow creation, agent execution, and backup operations
- Original response is returned for duplicate keys without re-execution
- Keys expire after 24 hours by default (configurable via `IDEMPOTENCY_TTL_SECONDS`)
- Enabled by default (disable via `IDEMPOTENCY_ENABLED=false`)

## 11. Secret Redaction

Sensitive data is automatically redacted from log output:

- API keys, passwords, tokens, and secrets are replaced with `[REDACTED]`
- Applies to all log levels and formats (JSON and plain text)
- Covers common patterns: Bearer tokens, AWS credentials, private keys, connection strings
- Enabled by default (disable via `REDACT_SECRETS=false`)

## 12. Residual Risks

| Risk | Status | Mitigation |
|------|--------|------------|
| Command injection in installers | **Fixed** | Replaced all `shell=True` calls with `shell=False` and list-based arguments; validated `SUDO_USER` against `/etc/passwd` |
| Redis without authentication | **Fixed** | Redis now requires a password generated at startup via `EVERSHADE_REDIS_PASSWORD` |
| Caddy trusting all proxies | **Fixed** | `trusted_proxies` restricted to internal Docker network ranges (172.16.0.0/12, 10.0.0.0/8, 192.168.0.0/16) |
| Hardcoded default API keys | **Fixed** | Removed all default fallback values; services require explicit keys in `.env` |
| Default encryption key | **Fixed** | Removed default fallback; `ENCRYPTION_KEY` must be set explicitly |
| Worktree mode is not a security boundary | **Documented** | Default changed to `container` mode; worktree requires explicit opt-in |
| Unpinned Docker image tags | **Fixed** | All images use pinned version tags; CI enforces this rule |
| Shell syntax with `shell=False` | **Fixed** | Replaced `||` and `&&` shell chains in `install-gui.py` with list-based arguments |
| Systemd service path injection | **Fixed** | All systemd service files now quote `WorkingDirectory`, `ExecStart`, `ExecStop` paths |
| Windows shortcut path injection | **Fixed** | Shortcut arguments properly escape `install_dir` for PowerShell/batch context |
| Ollama container hardening | **Fixed** | Added `no-new-privileges` security option; Ollama binds to `0.0.0.0` for internal network access |
| SSRF via Trapper | **Mitigated** | Private IP blocking, metadata endpoint blocking |
| Docker socket access for workstation manager | **Accepted** | Isolated behind narrow authenticated interface |
| DNS rebinding after SSRF check | **Accepted** | SSRF check validates URL at request time; DNS resolution happens at fetch time. Mitigated by network isolation. |
| User authentication (browser sessions) | **Complete** | Full user accounts with bcrypt password hashing, HMAC-signed sessions, RBAC, and SQLite persistence |

---

## 13. Reporting Security Issues

Report security vulnerabilities to the repository maintainers. Do not open public issues for security concerns.

**Responsible disclosure:** Allow reasonable time for patches before public disclosure.

---

## 14. Security Best Practices

### For Beginners

1. **Generate strong API keys** – Use `openssl rand -hex 32` for each service
2. **Never commit `.env`** – It's in `.gitignore`, but double-check before pushing
3. **Use minimal profile first** – Start small, add services as needed
4. **Keep Docker updated** – Run the latest stable Docker version
5. **Backup regularly** – Use `evershade backup` before major changes

### For Production

1. **Enable TLS** – Use the Caddy proxy profile or external reverse proxy
2. **Restrict firewall** – Only expose ports 80/443 to the internet
3. **Rotate keys periodically** – Use the credential rotation API
4. **Monitor logs** – Configure Sneaker alerts for suspicious activity
5. **Use server mode** – Set `EVERSHADE_MODE=server` for production deployments
6. **Enable rate limiting** – Configure appropriate limits for your traffic
7. **Audit access** – Review the audit trail regularly via `/api/audit/events`

### For Maximum Security

1. **Use container isolation** – Set `EVERSHADE_ISOLATION_MODE=container` for Slinker
2. **Network policies** – Configure workstation network policies with default-deny
3. **Secrets management** – Use Docker secrets instead of `.env` for production
4. **Seccomp profiles** – Apply custom Seccomp profiles for additional hardening
5. **Regular audits** – Run security tests: `./tests/run-all-tests.sh security`
